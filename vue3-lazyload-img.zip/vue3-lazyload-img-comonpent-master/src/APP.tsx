import HelloWorld from './components/HelloWorld.vue'

export default () => {
  return (
    <div>
        {/* <HelloWorld></HelloWorld> */}
    </div>
  )
}
